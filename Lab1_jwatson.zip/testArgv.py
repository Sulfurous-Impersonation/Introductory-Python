import sys

total = len(sys.argv)
cmdargs = str(sys.argv)
print ("The total number of args passed to the script %d " % total)
print ("Args list: %s" % str(sys.argv[0]))
print ("First argument: %s" % str(sys.argv[1]))
print ("Second argument: %s" % str(sys.argv[2]))

#The total number of args passed to the script 3
#Args list: testArgv.py
#First argument: a
#Second argument: b
#student@debian:~$ python3 testArgv.py 123 456
#The total number of args passed to the script 3 
#Args list: testArgv.py
#First argument: 123
#Second argument: 456

